BEGIN TRY
	BEGIN tran
		IF NOT EXISTS(SELECT * FROM sys.columns  WHERE NAME = N'Swift2023' and Object_ID = Object_ID(N'ParmsICC')) 
			BEGIN 
				ALTER TABLE ParmsICC ADD
				Swift2023 Bit NOT NULL CONSTRAINT DF_ParmsICC_Swift2023 DEFAULT 0;
          print 'Created Swift2023 column'
			END
			ELSE BEGIN
                print 'Swift2023 column already exists in this DB'
			 END
	COMMIT TRAN	
END TRY
BEGIN CATCH
Rollback tran
			PRINT 'Error modifying table. See the following message: '  + ERROR_MESSAGE()	  
END CATCH