BEGIN TRY
	BEGIN tran
	if Not Exists(Select CHARACTER_MAXIMUM_LENGTH from INFORMATION_SCHEMA.COLUMNS where TABLE_NAME = 'LCHistoryBalance'and COLUMN_NAME = 'ShipFrom' AND CHARACTER_MAXIMUM_LENGTH = '140')
	BEGIN 
					Alter Table LCHistoryBalance
	Alter Column ShipFrom varchar(140)
          print 'Altered ShipFrom column to be 140 characters'
			END
			ELSE BEGIN
                print 'Column length already 140'
			 END
	COMMIT TRAN	
END TRY
BEGIN CATCH
Rollback tran
			PRINT 'Error modifying table. See the following message: '  + ERROR_MESSAGE()	  
END CATCH
BEGIN TRY
	BEGIN tran
	if Not Exists(Select CHARACTER_MAXIMUM_LENGTH from INFORMATION_SCHEMA.COLUMNS where TABLE_NAME = 'LCHistoryBalance' and COLUMN_NAME = 'ShipTo' AND CHARACTER_MAXIMUM_LENGTH = '140')
	BEGIN
					Alter Table LCHistoryBalance
	Alter Column ShipTo varchar(140)
          print 'Altered ShipTo column to be 140 characters'
			END
			ELSE BEGIN
                print 'Column length already 140'
			 END
	COMMIT TRAN
END TRY
BEGIN CATCH
Rollback tran
			PRINT 'Error modifying table. See the following message: '  + ERROR_MESSAGE()
END CATCH
BEGIN TRY
	BEGIN tran
	if Not Exists(Select CHARACTER_MAXIMUM_LENGTH from INFORMATION_SCHEMA.COLUMNS where TABLE_NAME = 'LCHistoryBalance'and COLUMN_NAME = 'PortOfLoading' AND CHARACTER_MAXIMUM_LENGTH = '140')
	BEGIN
					Alter Table LCHistoryBalance
	Alter Column PortOfLoading varchar(140)
          print 'Altered PortOfLoading column to be 140 characters'
			END
			ELSE BEGIN
                print 'Column length already 140'
			 END
	COMMIT TRAN
END TRY
BEGIN CATCH
Rollback tran
			PRINT 'Error modifying table. See the following message: '  + ERROR_MESSAGE()
END CATCH
BEGIN TRY
	BEGIN tran
	if Not Exists(Select CHARACTER_MAXIMUM_LENGTH from INFORMATION_SCHEMA.COLUMNS where TABLE_NAME = 'LCHistoryBalance'and COLUMN_NAME = 'PortOfDischarge' AND CHARACTER_MAXIMUM_LENGTH = '140')
	BEGIN
					Alter Table LCHistoryBalance
	Alter Column PortofDischarge varchar(140)
          print 'Altered PortofDischarge column to be 140 characters'
			END
			ELSE BEGIN
                print 'Column length already 140'
			 END
	COMMIT TRAN
END TRY
BEGIN CATCH
Rollback tran
			PRINT 'Error modifying table. See the following message: '  + ERROR_MESSAGE()
END CATCH
