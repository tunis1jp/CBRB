Update ParmsGTS set SWIFT2023='Y'
Update WipItems set WipStatus='RCAL' where GtsService in ('IMP', 'EXP') and GtsProduct in ('ISS', 'AMD') and WipStatus not in ('SWFI', 'ICCI', 'RECV', 'APPROV', 'CANC')
Update WipItems set WipStatus = 'RCAL' where Pkey IN (Select w.Pkey from WipItems w inner join locprimary l on w.Pkey = l.TransPkey 
where w.GtsService  = 'STB' and GtsProduct in ('ISS', 'AMD', 'PAY') and WipStatus not in ('SWFI', 'ICCI', 'RECV', 'APPROV', 'CANC') and L.PurposeOfMessage <> '')
