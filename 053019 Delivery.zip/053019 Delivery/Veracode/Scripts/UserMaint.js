﻿
function ExpandAll(ChkExpandAll) 
{
        var checked = ChkExpandAll.checked
        
        ExpandMe("ACTLetter", checked);
        ExpandMe("IMPLetter", checked);
        ExpandMe("STBLetter", checked);
        ExpandMe("STBALetter", checked);
        ExpandMe("EXPLetter", checked);
        ExpandMe("SARLetter", checked);
        ExpandMe("ACCLetter", checked);
        ExpandMe("DIRLetter", checked);
        ExpandMe("CEXLetter", checked);
        ExpandMe("CIMLetter", checked);
        ExpandMe("MAILLetter", checked);
        ExpandMe("ADMLetter", checked);
        ExpandMe("CAMLetter", checked);
}

function ExpandMe(Here, Checked) {
    var collPanel
    var ThisCpePanel

    switch (Here) {
        case "ACTLetter":
            ThisCpePanel = "ACT_PnlBehaviorId";
            break;
        case "IMPLetter":
            ThisCpePanel = "IMP_PnlBehaviorId";
            break;
         case "STBLetter":
            ThisCpePanel = "STB_PnlBehaviorId";
            break;
         case "STBALetter":
            ThisCpePanel = "STBA_PnlBehaviorId";
            break;
         case "EXPLetter":
            ThisCpePanel = "EXP_PnlBehaviorId";
            break;
        case "SARLetter":
            ThisCpePanel = "SAR_PnlBehaviorId";
            break;
        case "ACCLetter":
            ThisCpePanel = "ACC_PnlBehaviorId";
            break;
        case "DIRLetter":
            ThisCpePanel = "DIR_PnlBehaviorId";
            break;
        case "CEXLetter":
            ThisCpePanel = "CEX_PnlBehaviorId";
            break;
        case "CIMLetter":
            ThisCpePanel = "CIM_PnlBehaviorId";
            break;
        case "MAILLetter":
            ThisCpePanel = "MAIL_PnlBehaviorId";
            break;
        case "ADMLetter":
            ThisCpePanel = "ADM_PnlBehaviorId";
            break;
        case "CAMLetter":
            ThisCpePanel = "CAM_PnlBehaviorId";
            break;
        default:
            ThisCpePanel = "";
            break;
    }

    if (ThisCpePanel != "") {
        collPanel = $find(ThisCpePanel);
        if (collPanel != null) {
            collPanel.set_Collapsed(Checked != true);
        }
    }
}
// -----------------------------------------
// These are for the email notification tab
// -----------------------------------------
function ExpandAllOnEmailTab(ChkExpandAll) 
{
        var checked = ChkExpandAll.checked
        
        ExpandMeOnEmailTab("IMPEmailTab", checked);
        ExpandMeOnEmailTab("STBEmailTab", checked);
        ExpandMeOnEmailTab("STBAEmailTab", checked);
        ExpandMeOnEmailTab("EXPEmailTab", checked);
        ExpandMeOnEmailTab("SAREmailTab", checked);
        ExpandMeOnEmailTab("ACCEmailTab", checked);
        ExpandMeOnEmailTab("DIREmailTab", checked);
        ExpandMeOnEmailTab("CEXEmailTab", checked);
        ExpandMeOnEmailTab("CIMEmailTab", checked);
}

function ExpandMeOnEmailTab(Here, Checked) {
    var collPanel
    var ThisCpePanel

    switch (Here) {
        case "IMPEmailTab":
            ThisCpePanel = "IMPCpeBehaviorId";
            break;
         case "STBEmailTab":
            ThisCpePanel = "STBCpeBehaviorId";
            break;
         case "STBAEmailTab":
            ThisCpePanel = "STBACpeBehaviorId";
            break;
         case "EXPEmailTab":
            ThisCpePanel = "EXPCpeBehaviorId";
            break;
        case "SAREmailTab":
            ThisCpePanel = "SARCpeBehaviorId";
            break;
        case "ACCEmailTab":
            ThisCpePanel = "ACCCpeBehaviorId";
            break;
        case "DIREmailTab":
            ThisCpePanel = "DIRCpeBehaviorId";
            break;
        case "CEXEmailTab":
            ThisCpePanel = "CEXCpeBehaviorId";
            break;
        case "CIMEmailTab":
            ThisCpePanel = "CIMCpeBehaviorId";
            break;
        default:
            ThisCpePanel = "";
            break;
    }

    if (ThisCpePanel != "") {
        collPanel = $find(ThisCpePanel);
        if (collPanel != null) {
            collPanel.set_Collapsed(Checked != true);
        }
    }
}

// -----------------------------------------
// -----------------------------------------
function ValidateEntitlements() {
    var chkEntitlement;
    var iCnt;
    
    chkEntitlement = document.getElementsByName("chkEntitlement");
	iCnt = chkEntitlement.length
    for (iIdx = 0;iIdx < iCnt; iIdx++) {
		if ((chkEntitlement[iIdx].id == 'Self-Approve') && (chkEntitlement[iIdx - 1].id == 'Approve')) {
			if (chkEntitlement[iIdx].checked && chkEntitlement[iIdx - 1].checked) {
				alert ("Approve and Self-Approve are mutually exclusive.")
				chkEntitlement[iIdx - 1].focus();
				return (false)
			}
		}
		
		if ((chkEntitlement[iIdx].id == 'Self-Release') && (chkEntitlement[iIdx - 1].id == 'Release')) {
			if (chkEntitlement[iIdx].checked && chkEntitlement[iIdx - 1].checked) {
				alert ("Release and Self-Release are mutually exclusive.")
				chkEntitlement[iIdx - 1].focus();
				return (false)
			}
		}
    }
}

function replaceChecks(chkBox, sClass) {
    var chkValue;
    var chkEntitlement;
    var chkAll;
    var iCnt;
    
    chkValue = chkBox.checked;
    
    chkEntitlement = document.getElementsByName("chkEntitlement");
	iCnt = chkEntitlement.length
    for (iIdx = 0;iIdx < iCnt; iIdx++) {
        if ((sClass == 'ALL') || (chkEntitlement[iIdx].className == sClass)) {
	        if ((chkEntitlement[iIdx].id == 'Approve') || (chkEntitlement[iIdx].id == 'Release')) {
	            chkEntitlement[iIdx].checked = false;
	        }
            else if ((chkEntitlement[iIdx].id == 'Change password') ||
                        (chkEntitlement[iIdx].id == 'Challenge Questions')) {
                chkEntitlement[iIdx].checked = true;
            }
            else {
                chkEntitlement[iIdx].checked = chkValue;
            }
        }
    }

    chkAll = document.getElementsByName("chkall");
	iCnt = chkAll.length
    for (iIdx = 0;iIdx < iCnt; iIdx++) {
        if ((sClass == 'ALL') || (chkAll[iIdx].className == sClass)) {
            chkAll[iIdx].checked = chkValue;
        }
    }
}

